Confluent for Kubernetes 2.0.0 is a complete, declarative API for deploying and operating Confluent Platform as a cloud-native system on Kubernetes.

Documentation for this is provided at https://docs.confluent.io/operator/current/overview.html .

This package includes the following:
- The Helm Chart to deploy Confluent for Kubernetes
- kubectl plugin to use and troubleshoot Confluent for Kubernetes